<?php



   $con=mysqli_connect("localhost","root","","test");

   if (mysqli_connect_errno($con)) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
}


$password=$_POST["userpass"]; 
$username=$_POST["username"]; 


$query = "INSERT INTO user (username, userpass) 
      VALUES ('$username','$password')";

       if ($query_run = mysqli_query($con, $query)) {
                $response["success"] = 1;
                  $response["message"] = "You have been registered"; 
                  die(json_encode($response));
       } 
       else 
           { 
                $response["success"] = 0;
                $response["message"] = "Invalid details";
                die(json_encode($response));
           } 
           mysql_close(); 


?>