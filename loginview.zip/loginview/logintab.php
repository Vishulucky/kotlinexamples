<?php



   $con=mysqli_connect("localhost","root","","vishal");

   if (mysqli_connect_errno($con)) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
}


// username and password sent from Form
$myusername=mysqli_real_escape_string($con,$_POST['dbid']); 
$mypassword=mysqli_real_escape_string($con,$_POST['userpass']); 

$sql="SELECT  * FROM user WHERE dbid='$myusername' and userpass='$mypassword'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);

$count=mysqli_num_rows($result);


// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1)
{
echo "success";
}
else 
{
$error="Your Login Name or Password is invalid";
echo "error ";
}

?>